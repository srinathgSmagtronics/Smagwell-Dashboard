from flask import Flask, render_template, request, jsonify
import json, os

app = Flask(__name__)

DATA_FILE = 'data.json'

def read_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def write_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/')
def display():
    return render_template('display.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/get_data')
def get_data():
    return jsonify(read_data())

@app.route('/update', methods=['POST'])
def update():
    data = {
        'name': request.form.get('name'),
        'admissionDate': request.form.get('admissionDate'),
        'typeOfCure': request.form.get('typeOfCure'),
        'criticality': request.form.get('criticality'),
        'medications': [m.strip() for m in request.form.get('medications','').split(',')],
        'insurance': request.form.get('insurance'),
        'approval': request.form.get('approval'),
        'diet': request.form.get('diet'),
        'testStatus': request.form.get('testStatus'),
        'spo2': request.form.get('spo2'),
        'temp': request.form.get('temp'),
        'hr': request.form.get('hr'),
        'rr': request.form.get('rr'),
        'notes': request.form.get('notes')
    }
    write_data(data)
    return "Data Updated. <a href='/'>View Display</a>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
